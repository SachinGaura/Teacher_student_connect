package com.cts.connect_project.service;

import com.cts.connect_project.bean.Help;

public interface HelpService {
	 public String insertHelp(Help help);
}
