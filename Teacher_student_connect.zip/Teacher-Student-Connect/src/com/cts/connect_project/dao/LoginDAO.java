package com.cts.connect_project.dao;

import com.cts.connect_project.bean.Login;

public interface LoginDAO {
	
	public int authenticateUser(Login login);
	

}
