package com.cts.connect_project.controller;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.cts.connect_project.bean.Register;
import com.cts.connect_project.service.RegisterService;
import com.cts.connect_project.service.RegisterServiceImpl;

/**
 * Servlet implementation class RegisterServlet
 */
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RegisterService registerService = new RegisterServiceImpl();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RegisterServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String age = request.getParameter("age");
		String gender = request.getParameter("gender");
		String cno = request.getParameter("cno");
		String cat = request.getParameter("cat");
		String userid = request.getParameter("userid");
		String password = request.getParameter("password");
		System.out.println(request.getParameter("userid"));
		System.out.println(request.getParameter("fname"));
		System.out.println(request.getParameter("lname"));
		System.out.println(request.getParameter("age"));
		System.out.println(request.getParameter("gender"));
		System.out.println(request.getParameter("cno"));
		System.out.println(request.getParameter("cat"));
		



	// File Upload
		
		InputStream inputStream = null; // input stream of the upload file

		// obtains the upload file part in this multipart request
		Part filePart = request.getPart("pic");
		if (filePart != null) {
			// prints out some information for debugging
			System.out.println(filePart.getName());
			System.out.println(filePart.getSize());
			System.out.println(filePart.getContentType());

			// obtains input stream of the upload file
			inputStream = filePart.getInputStream();
		}

		Register register = new Register();

		register.setFname(fname);
		register.setLname(lname);
		register.setAge(age);
		register.setGender(gender);
		register.setCno(cno);
		register.setCat(cat);
		register.setUserid(userid);
		register.setPassword(password);
		register.setPic(inputStream);
		   System.out.println(register);
		boolean userRegistered = registerService.registerUser(register);
		if (userRegistered) // On success, you can display a message to user on Home page
		{
			request.getRequestDispatcher("login.jsp").forward(request, response);
		} else {
			request.setAttribute("errMessage", userRegistered);
			request.getRequestDispatcher("index.jsp").include(request, response);
		}
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		String userType = req.getParameter("userType");

		resp.sendRedirect("Register.jsp?userType=" + userType);

	}

}
